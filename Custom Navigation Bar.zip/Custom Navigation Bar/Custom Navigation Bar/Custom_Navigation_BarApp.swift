//
//  Custom_Navigation_BarApp.swift
//  Custom Navigation Bar
//
//  Created by Priya Hansaliya on 30/07/24.
//

import SwiftUI

@main
struct Custom_Navigation_BarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
